@echo off
setlocal

rem Project root is one directory above this scripts folder.
set "PROJECT_ROOT=%~dp0.."
set "CAPTURE_DIR=%PROJECT_ROOT%\captures"

if not exist "%CAPTURE_DIR%\traffic_capture.pcapng" (
    echo [ERROR] traffic_capture.pcapng was not found in:
    echo %CAPTURE_DIR%
    pause
    exit /b 1
)

set "TSHARK=tshark.exe"
where tshark.exe >nul 2>nul
if errorlevel 1 (
    if exist "C:\Program Files\Wireshark\tshark.exe" (
        set "TSHARK=C:\Program Files\Wireshark\tshark.exe"
    ) else (
        echo [ERROR] tshark.exe was not found.
        echo Install Wireshark/TShark and make sure tshark.exe is available.
        pause
        exit /b 1
    )
)

echo Regenerating packets.csv...
echo.

"%TSHARK%" -r "%CAPTURE_DIR%\traffic_capture.pcapng" -T fields ^
-E header=y -E separator=, -E quote=d ^
-e frame.number ^
-e frame.time_relative ^
-e ip.src ^
-e ip.dst ^
-e ipv6.src ^
-e ipv6.dst ^
-e _ws.col.Protocol ^
-e tcp.srcport ^
-e tcp.dstport ^
-e udp.srcport ^
-e udp.dstport ^
-e tcp.analysis.retransmission ^
-e tcp.flags ^
-e tcp.flags.reset ^
-e frame.protocols ^
> "%CAPTURE_DIR%\packets.csv"

if errorlevel 1 (
    echo.
    echo [ERROR] TShark failed to generate packets.csv.
    pause
    exit /b 1
)

echo.
echo [OK] packets.csv regenerated successfully.
echo Location: %CAPTURE_DIR%\packets.csv
pause
endlocal
