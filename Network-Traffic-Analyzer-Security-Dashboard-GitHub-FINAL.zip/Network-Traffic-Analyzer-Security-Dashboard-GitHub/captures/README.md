# Capture data

Place your local Wireshark capture here as `traffic_capture.pcapng`.

Raw captures and generated packet CSV files are intentionally excluded from Git because they may contain private network information.
