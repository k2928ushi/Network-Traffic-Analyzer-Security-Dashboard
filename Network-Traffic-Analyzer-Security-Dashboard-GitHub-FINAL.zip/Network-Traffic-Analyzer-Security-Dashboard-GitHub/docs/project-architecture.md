# Project Architecture

```text
Wireshark capture (.pcapng)
          |
          v
       TShark
          |
          v
      packets.csv
          |
          v
   C++ Network Analyzer
          |
          +--> protocol statistics
          +--> source/destination IP statistics
          +--> TCP/UDP destination ports
          +--> TCP retransmission detection
          +--> TCP reset detection
          +--> SYN-based TCP port-scan indicator
          +--> DNS volume anomaly indicator
          |
          v
      analysis.js
          |
          v
 HTML/CSS/JavaScript Dashboard
```

The analyzer uses a relative project layout, so it is not tied to a OneDrive or user-specific Windows path.

The dashboard uses a sanitized demo `analysis.example.js` in the repository. Running the analyzer locally regenerates `analysis.js` from the user's own capture; that generated file is ignored by Git. The dashboard loads the generated file when present and otherwise displays the sanitized example.

## TLS metric note

The analyzer counts frames whose `frame.protocols` layer list contains `tls`. This is a layer-presence metric and can differ from other Wireshark views that use a different counting scope or dissection presentation. The README deliberately avoids treating those values as interchangeable without verification.
