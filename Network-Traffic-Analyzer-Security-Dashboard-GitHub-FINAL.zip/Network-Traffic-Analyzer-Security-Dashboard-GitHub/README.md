# Network Traffic Analyzer & Security Monitoring Dashboard

An offline network-security analysis project that combines **Wireshark/TShark, C++, and an HTML/CSS/JavaScript dashboard** to inspect packet captures and surface network-security indicators.

## Features

- Packet-count and protocol statistics
- Source and destination endpoint analysis
- Top TCP and UDP destination ports
- TCP retransmission detection
- TCP reset detection
- SYN-based TCP port-scan indicator
- DNS packet-volume anomaly indicator
- Automatically generated JavaScript analysis data
- Offline dashboard with charts and tables
- Privacy mode for portfolio screenshots
- Text analysis report generation

## Architecture

`PCAPNG → TShark → packets.csv → C++ Analyzer → analysis.js → Dashboard`

See [`docs/project-architecture.md`](docs/project-architecture.md).

## Tech Stack

- C++
- TShark / Wireshark
- TCP/IP, DNS, HTTP, TLS/QUIC, ICMPv6
- HTML
- CSS
- JavaScript

## Repository Structure

```text
.
├── analyzer/
│   └── main.cpp
├── captures/
│   └── README.md
├── dashboard/
│   ├── dashboard.html
│   └── analysis.example.js  # sanitized demo data kept in Git
├── scripts/
│   └── regenerate_packets_csv.bat
├── docs/
│   └── project-architecture.md
├── .gitignore
└── README.md
```

## Local Setup on Windows

### 1. Capture traffic

Save a Wireshark capture as:

```text
captures\traffic_capture.pcapng
```

### 2. Generate the CSV

Run:

```text
scripts\regenerate_packets_csv.bat
```

This exports the packet fields required by the analyzer, including `frame.protocols`.

### 3. Build the C++ analyzer

Open:

```text
analyzer\main.cpp
```

in Dev-C++ / GCC and build the program.

The analyzer automatically resolves the project root from the executable location, so it does not depend on a hard-coded user/OneDrive path.

### 4. Run the analyzer

The program reads:

```text
captures\packets.csv
```

and generates locally:

```text
dashboard\analysis.js
dashboard\network_analysis_report.txt
```

### 5. Open the dashboard

Open:

```text
dashboard\dashboard.html
```

in a browser.

## Privacy

Do **not** publish raw `.pcapng` files, packet CSVs, or generated analysis containing real internal IP addresses unless they have been deliberately sanitized.

The repository includes sanitized demo data in `dashboard/analysis.example.js`. Locally generated `dashboard/analysis.js` is ignored by Git because it may contain real endpoint data. The dashboard loads the sanitized example first and automatically uses the generated local file when it exists. Privacy Mode is also available for portfolio screenshots.

## Detection Scope

The current detection logic is deliberately lightweight and heuristic. TCP retransmissions and resets can occur during normal network operation, and a port-scan or DNS-volume indicator requires further investigation. These indicators do not, by themselves, establish malicious activity.

## TLS Metric Note

The analyzer counts frames with a `tls` layer in `frame.protocols`. This is a specific layer-presence metric and should not automatically be treated as identical to every Wireshark protocol-hierarchy or display-filter count.

## Project Status

Functional offline analyzer + dashboard pipeline with security indicators, generated analysis data, charts, tables, and privacy-safe demo data.
